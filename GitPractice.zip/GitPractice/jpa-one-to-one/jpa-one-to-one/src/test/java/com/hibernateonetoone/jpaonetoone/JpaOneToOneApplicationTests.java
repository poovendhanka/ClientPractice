package com.hibernateonetoone.jpaonetoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaOneToOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
