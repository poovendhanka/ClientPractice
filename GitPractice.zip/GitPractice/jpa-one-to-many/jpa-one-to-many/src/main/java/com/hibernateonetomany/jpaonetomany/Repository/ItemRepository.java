package com.hibernateonetomany.jpaonetomany.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hibernateonetomany.jpaonetomany.model.Item;

@Repository
public interface ItemRepository extends CrudRepository<Item,Long>{
	

}
