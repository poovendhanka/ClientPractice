package com.hibernateonetomany.jpaonetomany.service;

public class CartService {

}
