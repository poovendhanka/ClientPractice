package com.hibernateonetomany.jpaonetomany.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hibernateonetomany.jpaonetomany.model.Cart;

@Repository
public interface CartRepository extends CrudRepository<Cart, Long> {
	

}
